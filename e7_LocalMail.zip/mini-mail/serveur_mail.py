#!/usr/bin/env python3
"""Serveur de mail local - Python 3, aucune dépendance.

Utilisation :
  python3 serveur_mail.py adduser alice     # crée un compte (ou change son mot de passe)
  python3 serveur_mail.py deluser alice
  python3 serveur_mail.py users
  python3 serveur_mail.py run [port]        # lance le serveur (port par défaut : 8025)
"""
import getpass, hashlib, hmac, json, os, re, secrets, sqlite3, sys, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DB = os.environ.get("MAIL_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "mail.db"))
PORT = 8025
OPEN_REGISTRATION = True  # False = seuls les comptes créés avec "adduser" existent
TOKENS = {}  # jeton -> (utilisateur, expiration)


def db():
    c = sqlite3.connect(DB, timeout=10)
    c.row_factory = sqlite3.Row
    return c


def init():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(name TEXT PRIMARY KEY, salt TEXT, hash TEXT);
    CREATE TABLE IF NOT EXISTS messages(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender TEXT, recipient TEXT, subject TEXT, body TEXT, sent_at REAL,
        is_read INTEGER DEFAULT 0, del_sender INTEGER DEFAULT 0, del_recipient INTEGER DEFAULT 0);
    """)
    c.commit()
    c.close()


def hash_pw(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 100_000).hex()


def actions(path, c, me, d):
    """Traite une requête authentifiée. Retourne (code HTTP, réponse)."""
    if path == "/list":
        if d.get("box") == "sent":
            q = ("SELECT id, recipient AS who, subject, sent_at, 0 AS unread FROM messages "
                 "WHERE sender=? AND del_sender=0 ORDER BY sent_at DESC LIMIT 500")
        else:
            q = ("SELECT id, sender AS who, subject, sent_at, 1-is_read AS unread FROM messages "
                 "WHERE recipient=? AND del_recipient=0 ORDER BY sent_at DESC LIMIT 500")
        msgs = [dict(r) for r in c.execute(q, (me,))]
        unread = c.execute("SELECT COUNT(*) FROM messages WHERE recipient=? AND del_recipient=0 "
                           "AND is_read=0", (me,)).fetchone()[0]
        return 200, {"messages": msgs, "unread": unread}

    if path == "/read":
        m = c.execute("SELECT * FROM messages WHERE id=? AND (sender=? OR recipient=?)",
                      (d["id"], me, me)).fetchone()
        if not m:
            return 404, {"error": "Message introuvable"}
        if m["recipient"] == me:
            c.execute("UPDATE messages SET is_read=1 WHERE id=?", (m["id"],))
        return 200, dict(m)

    if path == "/send":
        dests = [x.strip().lower().split("@")[0]
                 for x in str(d["to"]).replace(";", ",").split(",") if x.strip()]
        if not dests:
            return 400, {"error": "Destinataire manquant"}
        for x in dests:
            if not c.execute("SELECT 1 FROM users WHERE name=?", (x,)).fetchone():
                return 400, {"error": f"Utilisateur inconnu : {x}"}
        for x in dests:
            c.execute("INSERT INTO messages(sender, recipient, subject, body, sent_at) "
                      "VALUES(?,?,?,?,?)",
                      (me, x, str(d.get("subject", ""))[:200], str(d.get("body", ""))[:100000], time.time()))
        return 200, {"ok": True}

    if path == "/delete":
        c.execute("UPDATE messages SET del_sender=1 WHERE id=? AND sender=?", (d["id"], me))
        c.execute("UPDATE messages SET del_recipient=1 WHERE id=? AND recipient=?", (d["id"], me))
        c.execute("DELETE FROM messages WHERE del_sender=1 AND del_recipient=1")
        return 200, {"ok": True}

    return 404, {"error": "Route inconnue"}


class Handler(BaseHTTPRequestHandler):
    server_version = "MiniMail/1.0"

    def log_message(self, *args):
        pass

    def _send(self, code, obj):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _login(self, d):
        c = db()
        try:
            r = c.execute("SELECT salt, hash FROM users WHERE name=?",
                          (str(d.get("user", "")).lower(),)).fetchone()
        finally:
            c.close()
        if not (r and hmac.compare_digest(hash_pw(str(d.get("password", "")), r["salt"]), r["hash"])):
            time.sleep(1)  # freine les essais en rafale
            return self._send(403, {"error": "Utilisateur ou mot de passe incorrect"})
        tok = secrets.token_hex(24)
        TOKENS[tok] = (str(d["user"]).lower(), time.time() + 7 * 86400)
        self._send(200, {"token": tok})

    def _register(self, d):
        name, pw = str(d.get("user", "")).strip().lower(), str(d.get("password", ""))
        if not OPEN_REGISTRATION:
            return self._send(403, {"error": "Création de compte désactivée sur ce serveur"})
        if not valid(name):
            return self._send(400, {"error": "Nom invalide (lettres, chiffres, . _ - ; 32 max)"})
        if len(pw) < 4:
            return self._send(400, {"error": "Mot de passe trop court (4 caractères minimum)"})
        c = db()
        try:
            if c.execute("SELECT 1 FROM users WHERE name=?", (name,)).fetchone():
                return self._send(409, {"error": "Ce nom d'utilisateur existe déjà"})
            salt = secrets.token_hex(16)
            c.execute("INSERT INTO users VALUES(?,?,?)", (name, salt, hash_pw(pw, salt)))
            c.commit()
        finally:
            c.close()
        self._send(200, {"ok": True})

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n > 2_000_000:
                return self._send(413, {"error": "Message trop gros"})
            d = json.loads(self.rfile.read(n) or b"{}")
            if self.path == "/login":
                return self._login(d)
            if self.path == "/register":
                return self._register(d)
            t = TOKENS.get(self.headers.get("Authorization", "").replace("Bearer ", ""))
            if not t or t[1] < time.time():
                return self._send(401, {"error": "Session expirée"})
            c = db()
            try:
                code, out = actions(self.path, c, t[0], d)
                c.commit()
            finally:
                c.close()
            self._send(code, out)
        except Exception:
            self._send(400, {"error": "Requête invalide"})


def valid(name):
    return re.fullmatch(r"[a-z0-9._-]{1,32}", name) is not None


def main():
    init()
    a = sys.argv[1:]
    if len(a) == 2 and a[0] == "adduser":
        name = a[1].lower()
        if not valid(name):
            sys.exit("Nom invalide (lettres, chiffres, . _ - ; 32 max).")
        pw = getpass.getpass("Mot de passe : ")
        if not pw or pw != getpass.getpass("Confirmer : "):
            sys.exit("Mots de passe vides ou différents.")
        salt = secrets.token_hex(16)
        c = db()
        c.execute("INSERT OR REPLACE INTO users VALUES(?,?,?)", (name, salt, hash_pw(pw, salt)))
        c.commit()
        print(f"Compte '{name}' enregistré.")
    elif len(a) == 2 and a[0] == "deluser":
        c = db()
        c.execute("DELETE FROM users WHERE name=?", (a[1].lower(),))
        c.commit()
        print("Compte supprimé.")
    elif a[:1] == ["users"]:
        for r in db().execute("SELECT name FROM users ORDER BY name"):
            print(r["name"])
    elif a[:1] == ["run"]:
        port = int(a[1]) if len(a) > 1 else PORT
        print(f"Serveur de mail sur le port {port} (Ctrl+C pour arrêter)")
        try:
            ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
        except KeyboardInterrupt:
            pass
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
