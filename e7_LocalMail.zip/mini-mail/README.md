# Mini Mail

Un petit service de mail **local** écrit en Python : un serveur sur un de tes ordinateurs, et une application pour y lire et envoyer des messages depuis les autres appareils de ton réseau (wifi maison). Aucune dépendance : seulement Python 3.7 ou plus.

> ⚠️ Conçu pour un **réseau local de confiance**. Les échanges ne sont **pas chiffrés** (HTTP) : ne l'expose pas sur Internet tel quel. Pour y accéder à distance, utilise un VPN privé comme Tailscale.

## Contenu

| Fichier | Rôle |
|---|---|
| `serveur_mail.py` | Le serveur (Windows, macOS, Linux) |
| `client_mail.py` | L'application (tkinter) |
| `lancer_serveur.bat` | Lanceur Windows avec redémarrage automatique |

## Installer le serveur

1. Installe [Python 3](https://www.python.org/downloads/) (sous Windows, coche « Add Python to PATH »).
2. Lance le serveur :
   ```
   python serveur_mail.py run
   ```
   (ou `python3` sous macOS/Linux, ou double-clique sur `lancer_serveur.bat` sous Windows). Port par défaut : 8025.
3. Trouve l'IP du serveur : `ipconfig` (Windows) ou `hostname -I` (Linux). Réserve-lui une IP fixe dans ta box.
4. Si le pare-feu bloque : ouvre le port 8025 en TCP pour les réseaux privés.

Les comptes se créent depuis le client (bouton « Créer un compte ») ou en ligne de commande :

```
python serveur_mail.py adduser alice
python serveur_mail.py deluser alice
python serveur_mail.py users
```

Pour interdire la création de compte depuis le client, mets `OPEN_REGISTRATION = False` en haut de `serveur_mail.py`.

Les messages sont stockés dans `mail.db`, à côté du serveur. **Ne le publie jamais** (il est déjà dans `.gitignore`).

## Installer le client

Sur chaque ordinateur (Linux : `sudo apt install python3-tk` d'abord) :

```
python client_mail.py
```

Saisis l'IP du serveur, le port 8025, ton nom d'utilisateur et ton mot de passe. Sous Windows, renomme le fichier en `client_mail.pyw` pour ne plus voir la console.

## Fonctionnalités

Réception, messages envoyés, nouveau message (plusieurs destinataires séparés par des virgules), réponse, suppression, messages non lus en gras, actualisation automatique toutes les 30 secondes.

## Licence

MIT, voir `LICENSE`.
