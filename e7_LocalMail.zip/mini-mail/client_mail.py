#!/usr/bin/env python3
"""Client de mail local (tkinter) - Windows, macOS, Linux. Aucune dépendance."""
import json, os, time, tkinter as tk, urllib.error, urllib.request
from tkinter import messagebox, ttk

CFG = os.path.join(os.path.expanduser("~"), ".mini_mail.json")


class Api:
    def __init__(self, host, port):
        self.base, self.port, self.token, self.cred = f"http://{host}:{port}", port, "", None

    def login(self, user, password):
        self.cred = None
        self.token = self.call("/login", user=user, password=password)["token"]
        self.cred = (user, password)

    def call(self, path, _retry=True, **data):
        req = urllib.request.Request(
            self.base + path, json.dumps(data).encode(),
            {"Content-Type": "application/json", "Authorization": "Bearer " + self.token})
        try:
            with urllib.request.urlopen(req, timeout=6) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            if e.code == 401 and _retry and self.cred:  # serveur redémarré : on se reconnecte
                self.login(*self.cred)
                return self.call(path, False, **data)
            try:
                msg = json.load(e)["error"]
            except (ValueError, KeyError):
                msg = f"Erreur {e.code}"
            raise RuntimeError(msg)
        except OSError as e:
            raise RuntimeError(f"Serveur injoignable : {e}")


class App:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Mini Mail")
        self.root.geometry("900x580")
        self.cfg = {"host": "", "port": 8025, "user": ""}
        try:
            with open(CFG) as f:
                self.cfg.update(json.load(f))
        except (OSError, ValueError):
            pass
        self.cur = None
        self.login_screen()
        self.root.mainloop()

    # ---------- Connexion ----------
    def login_screen(self):
        f = self.frame = ttk.Frame(self.root, padding=30)
        f.pack(expand=True)
        self.vars = {k: tk.StringVar(value=str(self.cfg[k])) for k in ("host", "port", "user")}
        self.pw = tk.StringVar()
        rows = (("Adresse du serveur", self.vars["host"], ""), ("Port", self.vars["port"], ""),
                ("Utilisateur", self.vars["user"], ""), ("Mot de passe", self.pw, "*"))
        for i, (label, var, show) in enumerate(rows):
            ttk.Label(f, text=label).grid(row=i, column=0, sticky="e", padx=6, pady=4)
            ttk.Entry(f, textvariable=var, show=show, width=28).grid(row=i, column=1, pady=4)
        ttk.Button(f, text="Se connecter", command=self.login).grid(row=4, column=0, columnspan=2, pady=(14, 4))
        ttk.Button(f, text="Créer un compte", command=self.register).grid(row=5, column=0, columnspan=2)
        self.root.bind("<Return>", lambda e: self.login())

    def login(self):
        host, user = self.vars["host"].get().strip(), self.vars["user"].get().strip().lower()
        try:
            self.api = Api(host, int(self.vars["port"].get()))
            self.api.login(user, self.pw.get())
        except (RuntimeError, ValueError) as e:
            return messagebox.showerror("Connexion", str(e))
        self.user = user
        try:
            with open(CFG, "w") as f:
                json.dump({"host": host, "port": self.api.port, "user": user}, f)
        except OSError:
            pass
        self.main_screen()

    def register(self):
        host = self.vars["host"].get().strip()
        w = tk.Toplevel(self.root)
        w.title("Créer un compte")
        v = {k: tk.StringVar() for k in ("user", "pw", "pw2")}
        rows = (("Nom d'utilisateur", "user", ""), ("Mot de passe", "pw", "*"), ("Confirmer", "pw2", "*"))
        for i, (label, key, show) in enumerate(rows):
            ttk.Label(w, text=label).grid(row=i, column=0, sticky="e", padx=8, pady=4)
            ttk.Entry(w, textvariable=v[key], show=show, width=26).grid(row=i, column=1, padx=8)

        def create():
            if v["pw"].get() != v["pw2"].get():
                return messagebox.showerror("Compte", "Les mots de passe sont différents.", parent=w)
            name = v["user"].get().strip().lower()
            try:
                Api(host, int(self.vars["port"].get())).call("/register", user=name, password=v["pw"].get())
            except (RuntimeError, ValueError) as e:
                return messagebox.showerror("Compte", str(e), parent=w)
            self.vars["user"].set(name)
            self.pw.set(v["pw"].get())
            w.destroy()
            messagebox.showinfo("Compte", "Compte créé ! Clique sur « Se connecter ».")

        ttk.Button(w, text="Créer le compte", command=create).grid(row=3, column=0, columnspan=2, pady=10)

    # ---------- Fenêtre principale ----------
    def main_screen(self):
        self.frame.destroy()
        self.root.unbind("<Return>")
        bar = ttk.Frame(self.root, padding=4)
        bar.pack(fill="x")
        for text, cmd in (("✉ Nouveau", self.compose), ("↩ Répondre", self.reply),
                          ("🗑 Supprimer", self.delete), ("⟳ Actualiser", self.refresh)):
            ttk.Button(bar, text=text, command=cmd).pack(side="left", padx=2)
        self.box = tk.StringVar(value="inbox")
        for text, val in (("Envoyés", "sent"), ("Réception", "inbox")):
            ttk.Radiobutton(bar, text=text, value=val, variable=self.box,
                            command=self.refresh).pack(side="right", padx=6)
        pan = ttk.PanedWindow(self.root, orient="vertical")
        pan.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(pan, columns=("who", "subject", "date"), show="headings", height=9)
        for col, title, width in (("who", "Contact", 160), ("subject", "Objet", 440), ("date", "Date", 140)):
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width)
        self.tree.tag_configure("unread", font=("TkDefaultFont", 10, "bold"))
        self.tree.bind("<<TreeviewSelect>>", self.show)
        self.text = tk.Text(pan, wrap="word", state="disabled", padx=8, pady=8)
        pan.add(self.tree, weight=1)
        pan.add(self.text, weight=2)
        self.refresh()
        self.tick()

    def tick(self):
        self.refresh(silent=True)
        self.root.after(30000, self.tick)

    def set_text(self, s):
        self.text.config(state="normal")
        self.text.delete("1.0", "end")
        self.text.insert("1.0", s)
        self.text.config(state="disabled")

    def refresh(self, silent=False):
        try:
            r = self.api.call("/list", box=self.box.get())
        except RuntimeError as e:
            if silent is not True:
                messagebox.showerror("Erreur", str(e))
            return
        sel = self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        for m in r["messages"]:
            date = time.strftime("%d/%m/%Y %H:%M", time.localtime(m["sent_at"]))
            self.tree.insert("", "end", iid=str(m["id"]),
                             values=(m["who"], m["subject"] or "(sans objet)", date),
                             tags=("unread",) if m["unread"] else ())
        if sel and self.tree.exists(sel[0]):
            self.tree.selection_set(sel[0])
        self.root.title(f"Mini Mail - {self.user} ({r['unread']} non lu(s))")

    def show(self, _=None):
        sel = self.tree.selection()
        if not sel:
            return
        try:
            m = self.api.call("/read", id=int(sel[0]))
        except RuntimeError as e:
            return messagebox.showerror("Erreur", str(e))
        self.cur = m
        self.tree.item(sel[0], tags=())
        date = time.strftime("%d/%m/%Y %H:%M", time.localtime(m["sent_at"]))
        self.set_text(f"De : {m['sender']}\nÀ : {m['recipient']}\nDate : {date}\n"
                      f"Objet : {m['subject']}\n\n{m['body']}")

    def delete(self):
        sel = self.tree.selection()
        if not sel or not messagebox.askyesno("Supprimer", "Supprimer ce message ?"):
            return
        try:
            self.api.call("/delete", id=int(sel[0]))
        except RuntimeError as e:
            return messagebox.showerror("Erreur", str(e))
        self.cur = None
        self.set_text("")
        self.refresh()

    # ---------- Écriture ----------
    def reply(self):
        m = self.cur
        if not m:
            return
        to = m["recipient"] if m["sender"] == self.user else m["sender"]
        subject = m["subject"] if m["subject"].lower().startswith("re:") else "Re: " + m["subject"]
        self.compose(to, subject, "\n\n> " + m["body"].replace("\n", "\n> "))

    def compose(self, to="", subject="", body=""):
        w = tk.Toplevel(self.root)
        w.title("Nouveau message")
        w.geometry("560x420")
        to_v, sub_v = tk.StringVar(value=to), tk.StringVar(value=subject)
        for i, (label, var) in enumerate((("À", to_v), ("Objet", sub_v))):
            ttk.Label(w, text=label).grid(row=i, column=0, sticky="e", padx=6, pady=4)
            ttk.Entry(w, textvariable=var).grid(row=i, column=1, sticky="ew", padx=6)
        t = tk.Text(w, wrap="word")
        t.grid(row=2, column=0, columnspan=2, sticky="nsew", padx=6, pady=6)
        t.insert("1.0", body)
        t.mark_set("insert", "1.0")
        w.columnconfigure(1, weight=1)
        w.rowconfigure(2, weight=1)

        def send():
            try:
                self.api.call("/send", to=to_v.get(), subject=sub_v.get(), body=t.get("1.0", "end").rstrip())
            except RuntimeError as e:
                return messagebox.showerror("Envoi", str(e), parent=w)
            w.destroy()
            self.refresh()

        ttk.Button(w, text="Envoyer", command=send).grid(row=3, column=1, sticky="e", padx=6, pady=6)


if __name__ == "__main__":
    App()
