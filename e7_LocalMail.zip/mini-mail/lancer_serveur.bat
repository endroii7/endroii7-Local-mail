@echo off
chcp 65001 >nul
title Serveur Mini Mail
cd /d "%~dp0"
echo Adresse(s) IP de ce PC :
ipconfig | findstr /i "IPv4"
echo.
:boucle
python serveur_mail.py run 8025
echo Le serveur s'est arrete. Redemarrage dans 5 secondes (Ctrl+C pour quitter)...
timeout /t 5 >nul
goto boucle
